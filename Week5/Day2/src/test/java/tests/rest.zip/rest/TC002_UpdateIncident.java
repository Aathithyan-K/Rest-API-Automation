package tests.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import freemarker.template.Configuration;
import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;
import lib.utils.ConfigurationManager;


public class TC002_UpdateIncident extends RESTAssuredBase{
	
	@BeforeTest//Reporting
	public void setValues() {
		testCaseName = "Update Incident with Rest Assured";
		testDescription = "Update Incident and Verify response Code";
		nodes = "Incident";
		authors = "Shan";
		category = "REST";
		//dataProvider
		dataFileName = "TC001";
		dataFileType = "JSON";
	}

	@Test(dataProvider = "fetchData",dependsOnMethods = "tests.rest.TC001_CreateIncident_Demo.createIncident")
	public void updateIncident(File file) throws FileNotFoundException, IOException {		
		
             
	Response response = putWithBodyParam(file,ConfigurationManager.configuration().incident()+"/"+sys_id);
    verifyResponseCode(response, ConfigurationManager.configuration().responsecodeforPut());
	}


}




















